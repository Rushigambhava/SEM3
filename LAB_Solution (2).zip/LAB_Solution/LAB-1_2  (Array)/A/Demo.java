import java.util.Scanner;
public class Demo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char a=sc.next().toLowerCase().charAt(0);
        
    }
}
// Explore String Methods 
