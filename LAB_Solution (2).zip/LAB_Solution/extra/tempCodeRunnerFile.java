    // list.addOrder(5);
        // list.addOrder(6);
        // list.addLast(10);
        // list.addLast(20);
        // list.addLast(30);